import sqlite3


schema = '''
CREATE TABLE IF NOT EXISTS users (
id INTEGER PRIMARY KEY AUTOINCREMENT,
username TEXT UNIQUE NOT NULL,
password TEXT NOT NULL,
role TEXT NOT NULL CHECK(role IN ('admin','user'))
);


CREATE TABLE IF NOT EXISTS quizzes (
id INTEGER PRIMARY KEY AUTOINCREMENT,
title TEXT NOT NULL,
description TEXT,
status TEXT NOT NULL CHECK(status IN ('active','inactive')) DEFAULT 'inactive'
);


CREATE TABLE IF NOT EXISTS questions (
id INTEGER PRIMARY KEY AUTOINCREMENT,
quiz_id INTEGER NOT NULL,
question TEXT NOT NULL,
option1 TEXT NOT NULL,
option2 TEXT NOT NULL,
option3 TEXT NOT NULL,
option4 TEXT NOT NULL,
answer TEXT NOT NULL,
FOREIGN KEY (quiz_id) REFERENCES quizzes(id) ON DELETE CASCADE
);


CREATE TABLE IF NOT EXISTS results (
id INTEGER PRIMARY KEY AUTOINCREMENT,
user_id INTEGER NOT NULL,
quiz_id INTEGER NOT NULL,
score INTEGER NOT NULL,
total INTEGER NOT NULL,
taken_at DATETIME DEFAULT (datetime('now','localtime')),
FOREIGN KEY (user_id) REFERENCES users(id),
FOREIGN KEY (quiz_id) REFERENCES quizzes(id)
);
'''


seed = [
("admin", "admin123", "admin"),
("user1", "user123", "user"),
]


conn = sqlite3.connect('database.db')
cur = conn.cursor()
cur.executescript(schema)


# seed users if not present
for u, p, r in seed:
    try:
        cur.execute("INSERT INTO users(username, password, role) VALUES (?, ?, ?)", (u, p, r))
    except sqlite3.IntegrityError:
        pass


conn.commit()
conn.close()
print('database initialized (database.db)')
