from flask import Flask, render_template, request, redirect, session, flash
import sqlite3
import os

app = Flask(__name__, instance_path=os.path.abspath(os.path.dirname(__file__)))
app.secret_key = "mysecret"

# Database connection
def get_db():
    conn = sqlite3.connect("database.db")
    conn.row_factory = sqlite3.Row
    return conn

@app.route("/")
def index():
    db = get_db()
    quizzes = db.execute("SELECT id, title, description FROM quizzes WHERE status='active'").fetchall()
    return render_template("index.html", quizzes=quizzes)

# -----------------------------
# USER REGISTER
# -----------------------------
@app.route("/register", methods=["GET", "POST"])
def register():
    if request.method == "POST":
        username = request.form["username"]
        password = request.form["password"]

        db = get_db()
        db.execute("INSERT INTO users(username, password, role) VALUES (?, ?, 'user')",
                   (username, password))
        db.commit()
        flash("Registered successfully. Please login.")
        return redirect("/login")
    return render_template("register.html")

# -----------------------------
# USER LOGIN
# -----------------------------
@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        username = request.form["username"]
        password = request.form["password"]

        db = get_db()
        user = db.execute("SELECT * FROM users WHERE username=? AND password=?",
                          (username, password)).fetchone()
        if user:
            session["user_id"] = user["id"]
            session["role"] = user["role"]
            session["username"] = user["username"]

            if user["role"] == "admin":
                return redirect("/admin")
            else:
                return redirect("/user")

        flash("Invalid credentials")
        return redirect("/login")
    return render_template("login.html")

# -----------------------------
# USER DASHBOARD
# -----------------------------
@app.route("/user")
def user_dashboard():
    db = get_db()
    quizzes = db.execute("SELECT id, title, description FROM quizzes WHERE status='active'").fetchall()
    return render_template("user_dashboard.html", quizzes=quizzes)

# -----------------------------
# ADMIN DASHBOARD
# -----------------------------
@app.route("/admin")
def admin_dashboard():
    db = get_db()
    quizzes = db.execute("SELECT id, title, description, status FROM quizzes ORDER BY id DESC").fetchall()
    users = db.execute("SELECT id, username, role FROM users ORDER BY id").fetchall()
    return render_template("admin_dashboard.html", quizzes=quizzes, users=users)

@app.route("/logout")
def logout():
    session.clear()
    return redirect("/")

# -----------------------------
# CREATE QUIZ
# -----------------------------
@app.route("/create_quiz", methods=["GET", "POST"])
def create_quiz():
    if request.method == "POST":
        title = request.form.get("title", "").strip()
        desc = request.form.get("description", "").strip()
        status = request.form.get("status", "inactive").strip()

        db = get_db()
        db.execute("INSERT INTO quizzes(title, description, status) VALUES (?, ?, ?)",
                   (title, desc, status))
        db.commit()
        return redirect("/admin")

    return render_template("create_quiz.html")

# -----------------------------
# ADD QUESTION
# -----------------------------
@app.route("/add_question/<quiz_id>", methods=["GET", "POST"])
def add_question(quiz_id):
    if request.method == "POST":
        q = request.form["question"]
        o1 = request.form["option1"]
        o2 = request.form["option2"]
        o3 = request.form["option3"]
        o4 = request.form["option4"]
        ans = request.form["answer"]

        db = get_db()
        db.execute("""
            INSERT INTO questions(quiz_id, question, option1, option2, option3, option4, answer)
            VALUES (?, ?, ?, ?, ?, ?, ?)
        """, (quiz_id, q, o1, o2, o3, o4, ans))
        db.commit()
        return "Question Added Successfully"

    return render_template("add_question.html")

# -----------------------------
# TAKE QUIZ (USER)
# -----------------------------
@app.route("/take_quiz/<id>", methods=["GET", "POST"])
def take_quiz(id):
    db = get_db()
    quiz = db.execute("SELECT * FROM quizzes WHERE id=?", (id,)).fetchone()
    questions = db.execute("SELECT * FROM questions WHERE quiz_id=?", (id,)).fetchall()

    if request.method == "POST":
        score = 0
        for q in questions:
            user_answer = request.form.get(str(q["id"]))
            if user_answer == q["answer"]:
                score += 1
        total = len(questions)
        db.execute("INSERT INTO results(user_id, quiz_id, score, total) VALUES (?, ?, ?, ?)",
                   (session["user_id"], id, score, total))
        db.commit()

        return redirect("/result/" + str(id))

    return render_template("take_quiz.html", questions=questions, quiz=quiz)

# -----------------------------
# SHOW RESULT
# -----------------------------
@app.route("/result/<quiz_id>")
def result(quiz_id):
    db = get_db()
    res = db.execute("""
        SELECT * FROM results
        WHERE user_id=? AND quiz_id=?
        ORDER BY id DESC LIMIT 1
    """, (session["user_id"], quiz_id)).fetchone()

    score = res["score"] if res else 0
    total = res["total"] if res else 0
    return render_template("result.html", score=score, total=total) 

@app.route("/admin/add", methods=["GET", "POST"])
def admin_add():
    if not session.get("user_id"):
        return redirect("/login")
    if session.get("role") != "admin":
        return redirect("/")
    if request.method == "POST":
        username = request.form.get("username", "").strip()
        password = request.form.get("password", "").strip()
        if not username or not password:
            flash("Username and password are required")
            return render_template("admin_add.html")
        db = get_db()
        try:
            db.execute(
                "INSERT INTO users(username, password, role) VALUES (?, ?, 'admin')",
                (username, password)
            )
            db.commit()
            flash(f"Admin user created: {username}")
            return redirect("/admin")
        except sqlite3.IntegrityError:
            flash("Username already exists")
    return render_template("admin_add.html")

app.run(debug=True)
